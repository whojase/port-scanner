# Этот код сканирует порты того айпи адреса, которого вы укажите

# Developer: JaseDev
# GitHub: https://github.com/whojase




import socket
from abc import ABC, abstractmethod

class PortScanner(ABC):
    @abstractmethod
    def scan_port(self, ipaddress, port):
        pass

class SimplePortScanner(PortScanner):
    def scan_port(self, ipaddress, port):
        try:
            sock = socket.socket()
            sock.connect((ipaddress, port))
            print('[+] Port Opened: ' + str(port))
            sock.close()
        except:
            print('[-] Port Closed: ' + str(port))

class PortRangeScanner:
    def __init__(self, scanner: PortScanner):
        self.scanner = scanner

    def scan(self, target, ports):
        for port in range(1, ports):
            self.scanner.scan_port(target, port)

class MultiTargetScanner:
    def __init__(self, scanner: PortRangeScanner):
        self.scanner = scanner

    def scan_targets(self, targets, ports):
        if ',' in targets:
            print('[*] Scanning multiple targets')
            for ip_addr in targets.split(','):
                self.scanner.scan(ip_addr.strip(' '), ports)
        else:
            self.scanner.scan(targets, ports)

# Usage
targets = input('[*] Enter target: ')
ports = int(input('[*] Enter how many ports: '))

scanner = SimplePortScanner()
range_scanner = PortRangeScanner(scanner)
multi_scanner = MultiTargetScanner(range_scanner)
multi_scanner.scan_targets(targets, ports)
